#
# Copyright (c) 2015-2016 by Hypsurus <hypsurus@mail.ru>
#
# See 'LICENSE' for copying
#


