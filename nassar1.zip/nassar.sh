cd /data/data/com.termux/files/home/nassar


#!/data/data/com.termux/files/usr/bin/bash
#colors
pt update && apt upgrade -y


g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
clear
toilet -f mono12 -F gay "  nassar"
echo -e "$y "
#figlet  -f big "           ESLAM  NASSAR  "
#chat
echo -e "$blue"

#--------------------------------------------------
ngrok(){
./dngrok.sh

}

#--------------------------------------------------



ngk(){
./http.sh


}
ngkk(){
./tcp.sh

}


#----------------------------------------
#for i in                                 Welcome to the nassar tool for the year 2019
#do
sleep 0.1

#for i in         s t a r t
#do
sleep 0.1



echo -e "                 $g ▇◤▔▔▔▔▔▔▔◥▇                                              $g ▇◤▔▔▔▔▔▔▔◥▇ "
sleep 0.3
echo -e "                 $g ▇$red▏◥▇◣┊◢▇◤$g▕▇                                              $g ▇$red▏◥▇◣┊◢▇◤$g▕▇ "
sleep 0.3
echo -e "                 $g ▇$red▏▃▆▅▎▅▆▃$g▕▇                                              $g ▇$red▏▃▆▅▎▅▆▃$g▕▇ "
sleep 0.3
echo -e "                 $g ▇$red▏╱▔▕▎▔▔╲$g▕▇                                              $g ▇$red▏╱▔▕▎▔▔╲$g▕▇ "
sleep 0.3
echo -e "                 $g ▇▇◣$blue◥▅▅▅◤$g◢▇▇                                              $g ▇▇◣$blue◥▅▅▅◤$g◢▇▇ "
sleep 0.3
echo -e "                 $g ▇▇▇◣$blue╲▇╱$g◢▇▇▇                                              $g ▇▇▇◣$blue╲▇╱$g◢▇▇▇ "
sleep 0.3
echo -e "                 $g ▇▇▇▇◣$blue▇$g◢▇▇▇▇                                              $g ▇▇▇▇◣$blue▇$g◢▇▇▇▇ "










sleep 0.3
echo -e "$red                                          #######################"
sleep 0.3
echo -e "$red                                          #                     #"
sleep 0.3
echo -e "$g                                          #  Welcome to nassar  #"
sleep 0.3
echo -e "$y                                          #                     #"
sleep 0.3
echo -e "$y                                          #######################"
sleep 0.3
echo -e "$p                  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"
sleep 0.3
echo -e "$y                  &                       I want$g to thank$red Ali Max   $y                   &"
sleep 0.3
echo -e "                  &                                                                    &"
sleep 0.3
echo -e "$blue                  &                         ###################                        &"
sleep 0.3
echo -e "$y                  &                         #$red  Ali $g      Max $y #                        &"
sleep 0.3
echo -e "$blue                  &                         ###################                        &"
sleep 0.3
echo -e "                  &                                                                    &"
sleep 0.3
echo -e "  $red                &  $g  *     *  $y  *  $p  *    *  $g  *     *   $y  *    *  $p  *    * $g   * $red    &"



#--------------------------------------
sleep 0.3
echo -e "                  &$red<<<<<<<<<<<<<<<<<<<<<<$green--------------------------$blue>>>>>>>>>>>>>>>>>>>>&"
sleep 0.3
echo -e "$g                  &                                                                    &"
sleep 0.3
echo -e "$g                  & ################################################################## &"
sleep 0.3
echo -e "$g                  & #[1 ]$red metasploit    $g  [2 ]$red termux        $g    [3 ]$red viruscreater $g  # &"
sleep 0.3
echo -e "$g                  & #[4 ]$red Facebook      $g  [5 ]$red ngrok         $g    [6 ]$red dos attack   $g  # &"
sleep 0.3
echo -e "$g                  & ################################################################## &"
sleep 0.3
echo -e "$g                  & # $red ESLAM NASSAR                                   Release 4.2.0 $g # &"
sleep 0.3
echo -e "$g                  & ################################################################## &"
sleep 0.3
echo -e "$g                                             [$red 00 $g]Exit  "

sleep 0.3

#--------------------------------------
echo -e "$red{&&&&&&my$blue&&&&&&&ip$green&&&&&&&&&}"
        curl ifconfig.me
echo -e "$blue"
	ifconfig wlan0 | grep -o 192..........
echo -e "$green "
echo -e "{&&&&&$blue&&&&&&$green&&&&&&&$red&&&&&&&&}"
#--------------------------------------
read -p  "number------>>"  u
if [ "$u" = "2" ]; then
# termux


cd $HOME
cd nassar
cd nano1
bash .termux
read -p "Entar------->>"
#------------------------------------
#------------------------------------
#---------------------------------------
#----------------------------------------
elif [ "$u" = "3"  ]; then
clear

cd $HOME
cd nassar
cd nano1
bash .Virud


read -p "Entar------>>"
#-----------------------------------------------
#-----------------------------------------------
#-----------------------------------------------
#-----------------------------------------------
#-----------------------------------------------
#-----------------------------------------------
#-----------------------------------------------"
#-----------------------------------------------

elif [ "$u" = "6" ]; then
cd $HOME
cd nassar
cd nano1
bash nano1

# dos attack

read -p "Entar-------->>"
#------------------------------------------------
elif [ "$u" = "4" ]; then
cd $HOME
cd nassar
cd nano1
bash nano2

#Facebook


read -p "Entar------->>"
#-----------------------------------------------
elif [ "$u" = "5" ]; then
chmod +x *
cd ngrok
chmod +x *
./sem.sh
read -p "     number------->  " alli

if [ "$alli" -eq "1"  ]; then
        ngk
fi
if [ "$alli" -eq "2"  ]; then
        ngkk
fi
if [ "$alli" -eq "3"  ]; then
        ngrok
fi

if [ "$alli" -eq "00"  ]; then
cd ..
        bash nassar.sh

else clear
fi
#---------------------------------------------
elif [ "$u" = "1" ]; then
cd nano1
bash nano

read -p "Entar------->>"


#-----------------------------------------------
elif [ "$u" = "00" ]; then
	toilet -f mono12 -F gay "good pay"
else :
bash nassar.sh

fi
