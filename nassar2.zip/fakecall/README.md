# fakecall [CLI Version]
# Note : Just For Fun
# How To Run?
# Use Ur Brain!
