echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
cd ..
        bash nassar.sh

else
cd &&  ./ngrok http $port
fi
