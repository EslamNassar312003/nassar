# Lazymux
Lazymux tools installer is very easy to use, only provided for lazy termux users.

## Screenshot
<img src="core/lazymux.png">

### Requirements
• Python 2.x

#### Installation and Using Lazymux
```
git clone https://github.com/Gameye98/Lazymux
```
```
cd Lazymux
```
```
python2 lazymux.py
```

## Contact Me
Line     : dtl.lily<br>
Telegram : @dtlily<br>
Facebook : cgi.izo

## Donation
Support me with your donation<br>
BTC:
```
1Eej5chjFzmdJdnQTfnTHeMQBYg5NPZ2Wm
```
DOGE:
```
DKNQfy2u4RTm4hAurUq67hkHLqdoVhD4fN
```
ETH:
```
0xa60d8d18b3b08bfa4a1675d5acfdbdbc839b40a2
```