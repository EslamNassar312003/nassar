apt-get install ruby -y
apt-get install curl -y
apt-get install tor -y
apt-get install perl -y
apt-get install git -y
apt-get install hydra -y
apt-get install python -y
apt-get install python2 -y
apt-get install php -y
apt-get install nmap -y
apt-get install apache2 -y
apt-get install cowsay -y
pip2 install mechanize
sleep 2
clear
echo "done ..."
