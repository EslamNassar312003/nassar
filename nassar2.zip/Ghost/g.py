import m
m.slam()

