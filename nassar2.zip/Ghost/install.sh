green='\e[1;32m'
echo -e $green
echo "•…• •…• •…• •…• •…• •…• •…• •…•"
echo  "~          Welcome           ~"
sleep 0.3
echo "======> Please wait for waiting <======"
pkg install python2 -y
pip2 install mechanize
pkg install figlet -y
clear
ls
