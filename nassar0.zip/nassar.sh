cd /data/data/com.termux/files/home/nassar


#!/data/data/com.termux/files/usr/bin/bash
#colors
pt update && apt upgrade -y


g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
clear
toilet -f mono12 -F gay "  nassar"


#--------------------------------------------------
ngrok(){
./dngrok.sh

}

#--------------------------------------------------



ngk(){
./http.sh


}
ngkk(){
./tcp.sh

}





echo -e "$red                                       #######################"
echo -e "$red                                       #                     #"
echo -e "$g                                       #  Welcome to nassar  #"
echo -e "$y                                       #                     #"
echo -e "$y                                       #######################"
echo -e "$p                   &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"
echo -e "$y                   &                   I want$g to thank$red Ali Max   $y                  &"
echo -e "                   &                                                               &"
echo -e "$blue                   &                     ###################                       &"
echo -e "$y                   &                     #$red  Ali $g      Max $y #                       &"
echo -e "$blue                   &                     ###################                       &"
echo -e "                   &                                                               &"
echo -e "  $red                 &  $g  *    *  $y  *  $p  *   *  $g  *    *  $y  *    *  $p  *    * $g   * $red   &"
#--------------------------------------
echo -e "                   $red<<<<<<<<<<<<<<<<<<<<$green--------------------------$blue>>>>>>>>>>>>>>>>>>>"
echo ""
echo -e "$g                   #################################################################"
echo -e "$g                   #$p [1 ] opan weeman     [2 ] opan Lazymux   [3 ] opan Ghost     $g #"
echo -e "$g                   #$p [4 ] opan OSIF       [5 ] opan virus     [6 ] opan fakecal   $g #"
echo -e "$g                   #$p [7 ] opan crackar    [8 ] opan T-Host    [9 ] opan Tool-x    $g #"
echo -e "$g                   #$p [10] Termux          [11] opan DarkFly   [12] opan txtool    $g #"
echo -e "$g                   #$p [13] opan Dr.Virus   [14] opan Alpine    [15] opan ngrok     $g #"
echo -e "$g                   #$p [16] opan fsociety                                           $g #"
echo -e "$g                   #################################################################"
echo -e "$g                   # ESLAM NASSAR                                    Release 1.2.0 #"
echo -e "$g                   #################################################################"
echo -e "$g                                             [00]Exit  "
sleep 0.1
#--------------------------------------
echo -e "$red{&&&&&&my$blue&&&&&&&ip$green&&&&&&&&&}"
        curl ifconfig.me
echo -e "$blue"
	ifconfig wlan0 | grep -o 192..........
echo -e "$green "
echo -e "{&&&&&$blue&&&&&&$green&&&&&&&$red&&&&&&&&}"
#--------------------------------------
read -p  "number------>>"  u
if [ "$u" = "2" ]; then
	clear
        git clone https://github.com/Gameye98/Lazymux
	clear
        cd Lazymux
	chmod +x *
	python2 lazymux.py
	read -p "Entar------->>"
#------------------------------------
elif [ "$u" = "1" ]; then
	git clone https://github.com/evait-security/weeman
	cd weeman
	python2 weeman.py
	read -p "Entar------->>"
#-------------------------------------
elif [ "$u" = "3" ]; then
	clear
	git clone https://github.com/islam928/Ghost
	cd Ghost
	bash install.sh
	python2 g.py
	read -p "Entar------->>"
#---------------------------------------
elif [ "$u" = "4"  ]; then
clear
git clone https://github.com/ciku370/OSIF
clear
cd OSIF
python2 osif.py
read -p "Entar-------->>"
#----------------------------------------
elif [ "$u" = "5"  ]; then
clear
git clone https://github.com/ERROR4317/viruscreater
clear
cd viruscreater
python2 virus.py
read -p "Entar------>>"
#-------------------------------------------
elif [ "$u" = "6"  ]; then
git clone https://github.com/siputra12/fakecall
clear
cd fakecall
php call.php
read -p "Entar------>>"
#-----------------------------------------------
elif [ "$u" = "7" ]; then
git clone https://github.com/AlatToll/cracker
cd cracker
clear
bash cracker.sh
read -p "Entar------>>"
#----------------------------------------------
elif [ "$u" = "8" ]; then
git clone https://github.com/Bhai4You/T-Host
cd T-Host
clear
chmod + x requirement.sh 127.0.0.1.sh
bash 127.0.0.1.sh


read -p "Entar----->>"

#-----------------------------------------------
 elif [ "$u" = "9" ]; then
clear
git clone https://github.com/Rajkumrdusad/Tool-X
cd Tool-X
chmod +x install.aex
sh install.aex
Tool-X
read -p "Entar----->>"
#-----------------------------------------------
elif [ "$u" = "10" ]; then
apt update -y
clear
apt upgrade -y
clear
pkg install git
dlear
pkg install python
pkg install python2
pkg install python3
pkg install bash
pkg install nano
clear
pkg install unzip
pkg install php
bash nassar.sh
read -p "Entar---->>"
#------------------------------------------------
elif [ "$u" = "11" ]; then

apt install git
apt install python
apt install python2
pkg install php
pip install requests
git clone https://github.com/Ranginang67/DarkFly-Tool
cd DarkFly-Tool
python2 install.py
DarkFly

read -p "Entar----->>"
#------------------------------------------------
elif [ "$u" = "12" ]; then

git clone https://github.com/kuburan/txtool
cd txtool
clear
bash install.py
txtool

read -p "Entar----->>"
#----------------------------------------------
elif [ "$u" = "13" ]; then

git clone https://github.com/joker0811/Dr.Virus
cd Dr.Virus
unzip Dr.Virus.zip
cd Dr.Virus
bash Guessing.sh

read -p "Entar------->>"
#-----------------------------------------------
elif [ "$u" = "14" ]; then
git clone https://github.com/Hax4us/TermuxAlpine
cd TermuxAlpine/
bash TermuxAlpine.sh
clear
startalpine


read -p "Entar------->>"
#-----------------------------------------------
elif [ "$u" = "16" ]; then



git clone https://github.com/Manisso/fsociety
cd fsociety
bash install.sh
python2 fsociety.py




read -p "Entar------->>"
#-----------------------------------------------
elif [ "$u" = "15" ]; then
chmod +x *
cd ngrok
./sem.sh
read -p "     number------->  " alli

if [ "$alli" -eq "1"  ]; then
        ngk
fi
if [ "$alli" -eq "2"  ]; then
        ngkk
fi
if [ "$alli" -eq "3"  ]; then
        ngrok
fi

if [ "$alli" -eq "00"  ]; then
cd ..
        bash nassar.sh

else clear
fi
#------------------------------------------------
elif [ "$u" = "00" ]; then
	toilet -f mono12 -F gay "good pay"
else :
bash nassar.sh

fi
